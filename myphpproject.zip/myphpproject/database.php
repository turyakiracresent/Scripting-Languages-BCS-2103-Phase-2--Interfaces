<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_system";
$conn = "";
// Creating a database connection
try{
    $conn = mysqli_connect($servername, $username, $password, $dbname);
}
catch(mysqli_sql_exception){
    echo "Could not connect to the database";

}
if($conn){
    echo "You Have Sucessfully Logined In. Congratulations!<br>";
}
?>
<html>
<style>
        body{
            background-color:greenyellow;
        }
    </style>
    <a href="index.html"><img src = "icon.png" alt="My logo" width="150" height="150"></a><br>
    <a href="index.html">Or Press Here To Go Back To The Home Page</a>
</html>